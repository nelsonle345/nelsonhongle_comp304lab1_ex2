package com.example.nelsonhongle_comp304lab2_ex1;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.content.Intent;

public class CheckoutActivity extends AppCompatActivity {

    private EditText fullNameInput;
    private EditText addressInput;
    private EditText cardNumberInput;
    private EditText cvvInput;
    private EditText expiryDateInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fullNameInput = findViewById(R.id.full_name_input);
        addressInput = findViewById(R.id.address_input);
        cardNumberInput = findViewById(R.id.card_number_input);
        cvvInput = findViewById(R.id.cvv_input);
        expiryDateInput = findViewById(R.id.expiry_date_input);

        Button enterButton = findViewById(R.id.enter_button);
        enterButton.setOnClickListener(v -> validateInputs());

        Button goBackButton = findViewById(R.id.go_back_button);
        goBackButton.setOnClickListener(v -> finish());
    }

    private void validateInputs() {
        if (TextUtils.isEmpty(fullNameInput.getText().toString())) {
            fullNameInput.setError("Full Name is required");
            return;
        }

        if (TextUtils.isEmpty(addressInput.getText().toString())) {
            addressInput.setError("Address is required");
            return;
        }

        if (TextUtils.isEmpty(cardNumberInput.getText().toString())) {
            cardNumberInput.setError("Card Number is required");
            return;
        } else if (cardNumberInput.getText().toString().length() != 16) {
            cardNumberInput.setError("Invalid Card Number");
            return;
        }

        if (TextUtils.isEmpty(cvvInput.getText().toString())) {
            cvvInput.setError("CVV is required");
            return;
        } else if (cvvInput.getText().toString().length() != 3) {
            cvvInput.setError("Invalid CVV");
            return;
        }

        if (TextUtils.isEmpty(expiryDateInput.getText().toString())) {
            expiryDateInput.setError("Expiration Date is required");
            return;
        }

        RadioGroup paymentMethodRadioGroup = findViewById(R.id.payment_method_radio_group);
        if (paymentMethodRadioGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Everything is Valid! Thank you!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

}