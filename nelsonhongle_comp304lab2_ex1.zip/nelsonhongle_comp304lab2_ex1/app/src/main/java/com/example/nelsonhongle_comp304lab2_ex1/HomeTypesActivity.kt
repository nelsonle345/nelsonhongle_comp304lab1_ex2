package com.example.nelsonhongle_comp304lab2_ex1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.ImageView
import android.widget.Spinner
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity

class HomeTypesActivity : AppCompatActivity() {
    private lateinit var homeTypesSpinner: Spinner
    private val homeTypes = arrayOf(
        "Detached Home",
        "Apartment",
        "Semi-detached Home",
        "Condominium Apartment",
        "Town House"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_screen)

        homeTypesSpinner = findViewById(R.id.home_types_spinner)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, homeTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        homeTypesSpinner.adapter = adapter

        homeTypesSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedHomeType = homeTypes[position]
                when (selectedHomeType) {
                    "Detached Home" -> {
                        val home = displayDetachedHomes()
                        updateSelectedHomeInfo(home)
                        updateSelectedHomesText(selectedHomeType)
                    }
                    "Apartment" -> {
                        val home = displayApartments()
                        updateSelectedHomeInfo(home)
                        updateSelectedHomesText(selectedHomeType)
                    }
                    "Semi-detached Home" -> {
                        val home = displaySemiDetachedHomes()
                        updateSelectedHomeInfo(home)
                        updateSelectedHomesText(selectedHomeType)
                    }
                    "Condominium Apartment" -> {
                        val home = displayCondominiumApartments()
                        updateSelectedHomeInfo(home)
                        updateSelectedHomesText(selectedHomeType)
                    }
                    "Town House" -> {
                        val home = displayTownHouses()
                        updateSelectedHomeInfo(home)
                        updateSelectedHomesText(selectedHomeType)
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Implementation for when nothing is selected
            }
        }

        val checkoutButton = findViewById<Button>(R.id.checkout_button)
        checkoutButton.setOnClickListener {
            val intent = Intent(this, CheckoutActivity::class.java)
            startActivity(intent)
        }

        val goBackButton = findViewById<Button>(R.id.go_back_button)
        goBackButton.setOnClickListener {
            finish()
        }
    }

    data class HomeViewReferences(
        val homeImageView: ImageView,
        val homeNameTextView: TextView,
        val homeAddressTextView: TextView,
        val homePriceTextView: TextView
    )

    private fun updateSelectedHomeInfo(homes: List<Home>) {
        val homeViews = listOf(
            HomeViewReferences(
                findViewById(R.id.home_image1),
                findViewById(R.id.home_name1),
                findViewById(R.id.home_address1),
                findViewById(R.id.home_price1)
            ),
            HomeViewReferences(
                findViewById(R.id.home_image2),
                findViewById(R.id.home_name2),
                findViewById(R.id.home_address2),
                findViewById(R.id.home_price2)
            ),
            HomeViewReferences(
                findViewById(R.id.home_image3),
                findViewById(R.id.home_name3),
                findViewById(R.id.home_address3),
                findViewById(R.id.home_price3)
            )
        )

        for ((index, home) in homes.withIndex()) {
            val (homeImageView, homeNameTextView, homeAddressTextView, homePriceTextView) = homeViews[index]
            homeNameTextView.text = home.name
            homeAddressTextView.text = home.address
            homePriceTextView.text = home.price
            homeImageView.setImageResource(home.imageResourceId)
        }
    }

    private fun updateSelectedHomesText(homeType: String) {
        val selectedHomesText = findViewById<TextView>(R.id.selected_homes_text)
        val displayText = "Selected homes: $homeType"
        selectedHomesText.text = displayText
    }

    data class Home(val name: String, val address: String, val price: String, val imageResourceId: Int)

    private fun displayDetachedHomes(): List<Home> {
        val detachedHomesList = listOf(
            Home("DetachedHome 1", "123 Street, City A", "$1,000,000.00", R.drawable.detachedhomes1),
            Home("DetachedHome 2", "456 Avenue, City B", "1,500,000.00", R.drawable.detachedhomes2),
            Home("DetachedHome 3", "789 Road, City C", "$2,000,000.00", R.drawable.detachedhomes3)
        )

        for ((index, home) in detachedHomesList.withIndex()) {
            Log.d("HomeInfo", "Detached Home $index - Name: ${home.name}, Address: ${home.address}, Price: ${home.price}")
            Log.d("HomeInfo", "Detached Home $index - Image Resource Id: ${home.imageResourceId}")
        }

        return detachedHomesList
    }

    private fun displaySemiDetachedHomes(): List<Home> {
        val semiDetachedHomesList = listOf(
            Home("Semi Detached Home 1", "23 Street, City A", "$1,250,000.00", R.drawable.semidetachedhome1),
            Home("Semi Detached Home 2", "26 Avenue, City B", "$2,250,000.00", R.drawable.semidetachedhome2),
            Home("Semi Detached Home 3", "9 Road, City C", "$1,500,000.00", R.drawable.semidetachedhome3)
        )

        for ((index, home) in semiDetachedHomesList.withIndex()) {
            Log.d("HomeInfo", "Semi Detached Home $index - Name: ${home.name}, Address: ${home.address}, Price: ${home.price}")
            Log.d("HomeInfo", "Semi Detached Home $index - Image Resource Id: ${home.imageResourceId}")
        }

        return semiDetachedHomesList
    }

    private fun displayCondominiumApartments(): List<Home> {
        val condominiumApartmentsList = listOf(
            Home("Condominium Apartment 1", "12 Street, City A", "$1,250,000.00", R.drawable.condominiumapartments1),
            Home("Condominium Apartment 2", "4 Avenue, City B", "$1,000,000.00", R.drawable.condominiumapartments2),
            Home("Condominium Apartment 3", "69 Road, City C", "$$1,500,000.00", R.drawable.condominiumapartments3)
        )

        for ((index, home) in condominiumApartmentsList.withIndex()) {
            Log.d("HomeInfo", "Condominium Apartment $index - Name: ${home.name}, Address: ${home.address}, Price: ${home.price}")
            Log.d("HomeInfo", "Condominium Apartment $index - Image Resource Id: ${home.imageResourceId}")
        }

        return condominiumApartmentsList
    }

    private fun displayTownHouses(): List<Home> {
        val townHousesList = listOf(
            Home("Town House 1", "23 Street, City A", "$500,000.00", R.drawable.townhouses1),
            Home("Town House 2", "33 Avenue, City B", "$800,000.00", R.drawable.townhouses2),
            Home("Town House 3", "755 Road, City C", "$520,000.00", R.drawable.townhouses3)
        )

        for ((index, home) in townHousesList.withIndex()) {
            Log.d("HomeInfo", "Town House $index - Name: ${home.name}, Address: ${home.address}, Price: ${home.price}")
            Log.d("HomeInfo", "Town House $index - Image Resource Id: ${home.imageResourceId}")
        }

        return townHousesList
    }

    private fun displayApartments(): List<Home> {
        val apartmentsList = listOf(
            Home("Apartment 1", "97 Street, City A", "$100,000.00", R.drawable.apartments1),
            Home("Apartment 2", "23 Avenue, City B", "$150,000.00", R.drawable.apartments2),
            Home("Apartment 3", "68 Road, City C", "$120,000.00", R.drawable.apartments3)
        )

        for ((index, home) in apartmentsList.withIndex()) {
            Log.d("HomeInfo", "Apartment $index - Name: ${home.name}, Address: ${home.address}, Price: ${home.price}")
            Log.d("HomeInfo", "Apartment $index - Image Resource Id: ${home.imageResourceId}")
        }

        return apartmentsList
    }

}
